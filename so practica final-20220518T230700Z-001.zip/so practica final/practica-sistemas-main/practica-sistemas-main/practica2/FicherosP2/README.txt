Miembros del grupo:
Juan Embid Sánchez (jembid@ucm.es)
Alberto Ramos Suárez (albram06@ucm.es)
