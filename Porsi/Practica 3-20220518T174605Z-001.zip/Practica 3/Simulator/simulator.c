#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

#define N_PARADAS 5
#define EN_RUTA 0
#define EN_PARADA 1
#define MAX_USUARIOS 40
#define USUARIOS 4

// Estado inicial
int estado = EN_RUTA;
int parada_actual = 0;
int n_ocupantes = 0;

// Personas esperando en cada parada
int esperando_parada[N_PARADAS];

// Personas esperando para bajar en cada parada
int esperando_bajar[N_PARADAS];

pthread_cond_t accion_usuario;
pthread_cond_t bus_llego_a_la_parada;
pthread_mutex_t mutex;

void Autobus_En_Parada();
void Conducir_Hasta_Siguiente_Parada();
void Subir_Autobus(int id_usuario, int origen);
void Bajar_Autobus(int id_usuario, int destino);

void* thread_autobus(void* args);
void* thread_usuario(void* args);
void Usuario(int id_usuario, int origen, int destino);


int main(int argc, char* argv[])
{

	
	pthread_t autobus;
	pthread_t usuarios[USUARIOS];


	for (int i = 0; i < N_PARADAS; i++)
	{
		esperando_parada[i] = 0;
		esperando_bajar[i] = 0;
	}

	// Opcional: obtener los argumentos del programa
	
	pthread_mutex_init(&mutex, NULL);
	pthread_cond_init(&accion_usuario, NULL);
	pthread_cond_init(&bus_llego_a_la_parada, NULL);
	
	pthread_create(&autobus, NULL, thread_autobus, NULL);


	for (int i = 0; i < USUARIOS; i++)
	{
		int* i_heap = malloc(sizeof(int));
		*i_heap = i;
		if(pthread_create(&usuarios[i], NULL, thread_usuario, i_heap) != 0){
			return 1;
		}
	}

	
	for (int i = 0; i < USUARIOS; i++)
	{
		if (pthread_join(usuarios[i], NULL) != 0) {
            return 1;
        }
	}

	pthread_join(autobus, NULL);
	pthread_mutex_destroy(&mutex);
	pthread_cond_destroy(&accion_usuario);
	pthread_cond_destroy(&bus_llego_a_la_parada);
	

	return 0;
}


void Autobus_En_Parada(){
	
	pthread_mutex_lock(&mutex);
	estado = EN_PARADA;

	printf("--------------------- \n");
	printf("Autobus llego a la parada %d . [subir: %d, bajar: %d] \n", parada_actual, esperando_parada[parada_actual], esperando_bajar[parada_actual]);

	pthread_cond_broadcast(&bus_llego_a_la_parada);

	while(esperando_parada[parada_actual] != 0 || esperando_bajar[parada_actual] != 0){
		pthread_cond_wait(&accion_usuario, &mutex);
	}

	pthread_mutex_unlock(&mutex);
}

void Conducir_Hasta_Siguiente_Parada(){

	pthread_mutex_lock(&mutex);
	estado = EN_RUTA;

	printf("Conduciendo ... \n");
	sleep(1); // tiempo en llegar de un lugar a otro

	parada_actual++;
	if(parada_actual == N_PARADAS)
		parada_actual = 0;

	pthread_mutex_unlock(&mutex);

}

void Subir_Autobus(int id_usuario, int origen){
	pthread_mutex_lock(&mutex);
	
	esperando_parada[origen]++;

	printf("Usuario %d llega a la parada %d \n", id_usuario, origen);

	while(parada_actual != origen){
		pthread_cond_wait(&bus_llego_a_la_parada, &mutex);
	}

	printf("Usuario %d sube al autobus \n", id_usuario);

	esperando_parada[origen]--;

	pthread_cond_signal(&accion_usuario);

	pthread_mutex_unlock(&mutex);
}

void Bajar_Autobus(int id_usuario, int destino){
	pthread_mutex_lock(&mutex);
	
	esperando_bajar[destino]++;

	while(parada_actual != destino){
		pthread_cond_wait(&bus_llego_a_la_parada, &mutex);
	}

	printf("Usuario %d baja del autobus \n", id_usuario);

	esperando_bajar[destino]--;

	pthread_cond_signal(&accion_usuario);

	pthread_mutex_unlock(&mutex);
}


void* thread_autobus(void* args){
	printf("AUTOBUS CREADO \n");

	while(1){
		Autobus_En_Parada();
		Conducir_Hasta_Siguiente_Parada();
	}
}

void* thread_usuario(void* args){
	int id_usuario = *(int*)args;
	int a;
	int b;

	printf("USUARIO CREADO \n");
	
	while(1){
		a=rand() % N_PARADAS;
		do{
			b=rand() % N_PARADAS;
		}
		while(a==b);
		Usuario(id_usuario, a,b);
	}
}

void Usuario(int id_usuario, int origen, int destino){
	// Esperar a que el autobus este en parada origen para subir
	Subir_Autobus(id_usuario, origen);

	//Bajar en estación destino
	Bajar_Autobus(id_usuario, destino);
}

