#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(int argc, char* argv[])
{
	if (argc!=2){
		fprintf(stderr, "Usage: %s <command>\n", argv[0]);
		exit(1);
	}

	pid_t pid;
	pid = fork();
	if (pid == 0) {
		execl("/bin/ls", argv[1], NULL);
		//fprintf(stdout, "%s %s\n", argv[0], argv[1]);
	}
	else {
		wait(NULL);
		
	}

	exit(0);
	//return system(argv[1]);
}

