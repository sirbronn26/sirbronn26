#!/usr/bin/bash


# 1
if [ -e "mytar" ] && [ -x "mytar" ]
then
    echo "El archivo mytar si existe y es ejecutable"
else
    echo "el archivo mytar no existe"
    exit
fi


# 2
if [ -d "tmp" ]
then
    rm -r "tmp"
fi

# 3
mkdir tmp
cd tmp

# 4
touch file1.txt
echo "Hello World!" > file1.txt

touch file2.txt
head -n +10 /etc/passwd > file2.txt

touch file3.dat
head -c +1024 /dev/urandom > file3.dat

# 5
../mytar -cf filetar.mtar file1.txt file2.txt file3.dat

# 6
mkdir out
cp filetar.mtar out

# 7
cd out
../../mytar -xf filetar.mtar

# 8 y 9
DIF1=$(diff file1.txt ../file1.txt)
DIF2=$(diff file2.txt ../file2.txt)
DIF3=$(diff file3.dat ../file3.dat)

if [ "$DIF1" == "" ] && [ "$DIF2" == "" ] && [ "$DIF3" == "" ]
then
    cd ../..
    echo "Correct"
    exit 0
else
    cd ../..
    echo "No funciona"
    exit 1
fi

