#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "mytar.h"

extern char *use;

/** Copy nBytes bytes from the origin file to the destination file.
 *
 * origin: pointer to the FILE descriptor associated with the origin file
 * destination:  pointer to the FILE descriptor associated with the destination file
 * nBytes: number of bytes to copy
 *
 * Returns the number of bytes actually copied or -1 if an error occured.
 */
int
copynFile(FILE * origin, FILE * destination, int nBytes)
{

	int numberBytes = 0;
	while(numberBytes < nBytes && !feof(origin)){
		putc(getc(origin), destination);
		numberBytes++;
	}

	if(numberBytes < nBytes && !feof(origin)){
		return -1;
	}


	return numberBytes;
}

/** Loads a string from a file.
 *
 * file: pointer to the FILE descriptor 
 * 
 * The loadstr() function must allocate memory from the heap to store 
 * the contents of the string read from the FILE. 
 * Once the string has been properly built in memory, the function returns
 * the starting address of the string (pointer returned by malloc()) 
 * 
 * Returns: !=NULL if success, NULL if error
 */
char*
loadstr(FILE * file)
{
	int numBytes = 0;
	char c;

	while((c = getc(file)) != EOF){
		numBytes++;
	}

	if(fseek(file, -numBytes, SEEK_CUR ) != 0){
		return NULL;
	}

	char *string = malloc(numBytes+1);
	int i = 0;

	while((c = getc(file)) != '\0'){
		//printf("c: %c \n", c);
		string[i] = c;
		i++;
	}

	string[i] = '\0';

	return string;
}

/** Read tarball header and store it in memory.
 *
 * tarFile: pointer to the tarball's FILE descriptor 
 * nFiles: output parameter. Used to return the number 
 * of files stored in the tarball archive (first 4 bytes of the header).
 *
 * On success it returns the starting memory address of an array that stores 
 * the (name,size) pairs read from the tar file. Upon failure, the function returns NULL.
 */
stHeaderEntry*
readHeader(FILE * tarFile, int *nFiles)
{
	if(fread(nFiles, sizeof(unsigned int), 1, tarFile) < 1){
		perror("int no pudo ser leído correctamente");
		fclose(tarFile);
		return NULL;
	}

	char *name;
	int size;

	stHeaderEntry arrayHeaderEntries[*nFiles];

	for (int i = 0; i < *nFiles; i++)
	{

		//Leer name
		name = loadstr(tarFile);

		//Leer size
		if(fread(&size, sizeof(unsigned int), 1, tarFile) < 1){
			perror("int no pudo ser leído correctamente");
			fclose(tarFile);
			return NULL;
		}

		stHeaderEntry headerEntry = {.name=name , .size=size};
		
		arrayHeaderEntries[i] = headerEntry;
	}

	stHeaderEntry *arrayHeaderEntriesHeap = malloc(sizeof(arrayHeaderEntries));
	//copy from stack to heap
	for (int i = 0; i < *nFiles; i++)
	{
		arrayHeaderEntriesHeap[i] = arrayHeaderEntries[i];
	}

	return arrayHeaderEntriesHeap;
}

/** Creates a tarball archive 
 *
 * nfiles: number of files to be stored in the tarball
 * filenames: array with the path names of the files to be included in the tarball
 * tarname: name of the tarball archive
 * 
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE. 
 * (macros defined in stdlib.h).
 *
 * HINTS: First reserve room in the file to store the tarball header.
 * Move the file's position indicator to the data section (skip the header)
 * and dump the contents of the source files (one by one) in the tarball archive. 
 * At the same time, build the representation of the tarball header in memory.
 * Finally, rewind the file's position indicator, write the number of files as well as 
 * the (file name,file size) pairs in the tar archive.
 *
 * Important reminder: to calculate the room needed for the header, a simple sizeof 
 * of stHeaderEntry will not work. Bear in mind that, on disk, file names found in (name,size) 
 * pairs occupy strlen(name)+1 bytes.
 *
 */
int
createTar(int nFiles, char *fileNames[], char tarName[])
{
	// Calcular size del header
	int fileNamesSize = 0;

	for (int i = 0; i < nFiles; i++)
	{
		fileNamesSize += strlen(fileNames[i]) + 1;
	}

	int headerSize = sizeof(int) + fileNamesSize + sizeof(unsigned int) * nFiles;

	// Crear archivo mtar
	FILE *ficheroDestino = fopen(tarName, "w");
	if (ficheroDestino < 0){
        perror("fichero no se pudo abrir");    
		return EXIT_FAILURE;
    }	   


	// Mover cursor a posicion para empezar a escribir los datos despues del header
	if(fseek(ficheroDestino, headerSize, SEEK_SET) != 0){
		return EXIT_FAILURE;
	}

	// Escribir datos y crear representación del header

	stHeaderEntry *arrayHeaderEntries = malloc(fileNamesSize + sizeof(unsigned int) * nFiles);

	for (int i = 0; i < nFiles; i++)
	{
		FILE *ficheroOrigen = fopen(fileNames[i], "r");
		if (ficheroOrigen < 0){
			perror("fichero no se pudo abrir");   
			free(arrayHeaderEntries);
			fclose(ficheroDestino);
			return EXIT_FAILURE;
    	}

		// Calcular size del fichero de origen
		if(fseek(ficheroOrigen, 0, SEEK_END) != 0){
			fclose(ficheroDestino);
			fclose(ficheroOrigen);
			free(arrayHeaderEntries);
			return EXIT_FAILURE;
		}
		int sizeFicheroOrigen = ftell(ficheroOrigen);
		rewind(ficheroOrigen);

		// Copiar archivo
		copynFile(ficheroOrigen, ficheroDestino, sizeFicheroOrigen);
		fclose(ficheroOrigen);

		// Header entry
		stHeaderEntry headerEntry = {.name = fileNames[i], .size = sizeFicheroOrigen};
		arrayHeaderEntries[i] = headerEntry;
	}
	
	rewind(ficheroDestino);

	// Escribir en el header el numero de ficheros
	if(fwrite(&nFiles, sizeof(int), 1, ficheroDestino) < 1){
		return EXIT_FAILURE;
	}

	// Escribir en el header la informacion de cada archivo copiado (nombre y size)
	for (int i = 0; i < nFiles; i++)
	{
		if(fwrite(arrayHeaderEntries[i].name, sizeof(char)*(strlen(arrayHeaderEntries[i].name) + 1), 1, ficheroDestino) < 1){
			return EXIT_FAILURE;
		}
		if(fwrite(&arrayHeaderEntries[i].size, sizeof(unsigned int), 1, ficheroDestino) < 1){
			return EXIT_FAILURE;
		}
	}
	

	free(arrayHeaderEntries);
	
	//fclose(ficheroDestino);

	return EXIT_SUCCESS;
}

/** Extract files stored in a tarball archive
 *
 * tarName: tarball's pathname
 *
 * On success, it returns EXIT_SUCCESS; upon error it returns EXIT_FAILURE. 
 * (macros defined in stdlib.h).
 *
 * HINTS: First load the tarball's header into memory.
 * After reading the header, the file position indicator will be located at the 
 * tarball's data section. By using information from the 
 * header --number of files and (file name, file size) pairs--, extract files 
 * stored in the data section of the tarball.
 *
 */
int
extractTar(char tarName[])
{
	FILE *ficheroMtar = fopen(tarName, "r");
	if (ficheroMtar < 0){
		perror("fichero no se pudo abrir");    
		return EXIT_FAILURE;
    }
	
	int nFiles;

	stHeaderEntry *arrayHeaderEntries = readHeader(ficheroMtar, &nFiles); 

	for (int i = 0; i < nFiles; i++)
	{
		//printf("%i: %s, %i \n", i, arrayHeaderEntriesHeap[i].name, arrayHeaderEntriesHeap[i].size);

		// leer el fichero y guardar todo el contenido en una variable
		char *contenido = malloc(arrayHeaderEntries[i].size);
		if(fread(contenido, arrayHeaderEntries[i].size, 1, ficheroMtar) < 1){
			free(arrayHeaderEntries);
			free(contenido);
			fclose(ficheroMtar);
			return EXIT_FAILURE;
		}

		// escribir todo en nuevo fichero
		FILE *ficheroDestino = fopen(arrayHeaderEntries[i].name, "w");
		if (ficheroDestino < 0){
			perror("fichero no se pudo abrir");  
			free(arrayHeaderEntries);
			free(contenido);
			fclose(ficheroMtar);  
			return EXIT_FAILURE;
    	}
		
		if(fwrite(contenido, arrayHeaderEntries[i].size, 1, ficheroDestino) < 1){
			return EXIT_FAILURE;
		}
		fclose(ficheroDestino);

		free(contenido);
	}


	return EXIT_SUCCESS;
}