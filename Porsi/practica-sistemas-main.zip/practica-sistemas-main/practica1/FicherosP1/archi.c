#include "archi.h"

int main(void)
{
	printf("Hello ...%d\n", VAR);
}

