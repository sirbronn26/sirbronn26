En esta carpeta podemos ir subiendo apuntes tanto teóricos como prácticos para el examen
